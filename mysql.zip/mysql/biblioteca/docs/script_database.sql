DROP DATABASE IF EXISTS prueba;
CREATE DATABASE prueba;
USE prueba;

DROP TABLE IF EXISTS usuarios;
CREATE TABLE  usuarios (
    id_usuario INt PRIMARY KEY AUTO_INCREMENT,
    nombre_completo VARCHAR(255) NOT NULL,
    identificacion VARCHAR(255) NOT NULL UNIQUE,
    correo VARCHAR(255) DEFAULT NULL,
    telefono VARCHAR(100) DEFAULT NULL,
    creted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS libros;
CREATE TABLE libros (
    isbn VARCHAR(100) PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    anio_de_publicacion YEAR NOT NULL,
    autor VARCHAR(100) NOT NULL,
    creted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS prestamos;
CREATE TABLE prestamos (
    id_prestamos INT PRIMARY KEY AUTO_INCREMENT,
    isbn VARCHAR(100),
    id_usuario INT,
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion DATE NOT NULL,
    estado ENUM('entregado', 'retrasado', 'activo') DEFAULT NULL,
    creted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (id_usuario) REFERENCES usuarios (id_usuario) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (isbn) REFERENCES libros (isbn) ON DELETE SET NULL ON UPDATE CASCADE
);

-- SELECT * FROM usuarios;
-- SELECT * FROM libros;
-- SELECT * FROM prestamos;