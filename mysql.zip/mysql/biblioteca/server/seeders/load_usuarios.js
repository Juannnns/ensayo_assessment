// CARGA LOS USERS A LA BASE DE DATOS
import fs from 'fs';
import path from 'path';
import csv from 'csv-parser';
import { pool } from '../conexion_database.js'


export async function cargarUsuariosAlaBaseDeDatos() {

    const rutaArchivo = path.resolve('./server/data/users.csv');
    const usuarios = [];

    return new Promise((resolve, reject) => {
        fs.createReadStream(rutaArchivo)
            .pipe(csv({ separator: ';' }))
            .on('data', (fila) => {
                usuarios.push([
                    fila.id_usuario,
                    fila.nombre_completo,
                    fila.identificacion,
                    fila.correo,
                    fila.telefono
                ]);
            })
            .on('end', async () => {
                try {
                    const sql = 'INSERT INTO usuarios (id_usuario,nombre_completo,identificacion,correo,telefono) VALUES ?';
                    const [result] = await pool.query(sql, [usuarios]);

                    console.log(`Se insertaron ${result.affectedRows} autores.`);
                    resolve();
                } catch (error) {
                    console.error('Error al insertar usuarios', error.message);
                    reject(error);
                }
            })
            .on('error', (error) => {
                console.log('Error al leer el archivo CSV de usuarios', error.message);
                reject(error);
            });
    });
}